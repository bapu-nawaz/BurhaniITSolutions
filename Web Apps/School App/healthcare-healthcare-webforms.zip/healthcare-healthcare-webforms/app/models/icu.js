app.factory('Icu', [function(){

    /**
     *  Name: Icu (Constructor)
     *  Purpose: initialize variables for first use
     */
    function Icu() {
        
    };
    

    return Icu;

}]);